BOOKDEAL FINDER — ANDROID PROJECT

This ZIP contains the Android Studio source project and the supplied BookDeal Finder website files bundled inside the app.
It is not a compiled APK yet.

BUILD AN INSTALLABLE APK
1. On a Windows/Mac/Linux computer, install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted BookDealFinderAndroid folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, choose Locate. The APK is in app/build/outputs/apk/debug/.
7. Transfer that APK to your OnePlus Nord CE 2, tap it, and allow Chrome/Files to install unknown apps if Android asks.

IMPORTANT
- The app starts with the supplied website files bundled locally, so the search interface opens without depending on the Netlify address.
- Marketplace search links require internet and open in the browser.
- The provided site code searches marketplace search pages and lets you compare manually entered deals; it does not automatically scrape or guarantee every listing.
- The public Netlify URL supplied in chat returned HTTP 401 Unauthorized when checked, so this project uses the website source ZIP rather than depending on that protected URL.
- A computer with Android Studio and Android SDK is required to compile this source project into an APK. The current build environment has Java but no Android SDK or Gradle installation, so no installable APK has been produced here.


VERSION 1.1 UPDATE
- Adds a separate offline page filtered to advertised old-book scrap listings under Rs 20/kg.
- Adds seller/source links and local Bhimavaram enquiry details.
- Public listings are leads only; prices, minimum quantities, stock and delivery must be confirmed.

Update 1.2: This is an update to the existing BookDeal Finder app (same applicationId in.bookdealfinder.app), not a separate app. The researched scrap buyer, shop drop-off, used-book shop and bulk price directory is integrated into the main screen. Rates and service areas are leads and must be reconfirmed.
