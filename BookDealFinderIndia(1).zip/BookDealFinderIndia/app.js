const $ = id => document.getElementById(id);
const marketplaces = [
  {name:"Google Shopping / Search",icon:"🔎",desc:"Broad web search for scrap and used stock",url:q=>`https://www.google.com/search?tbm=shop&q=${encodeURIComponent(q)}`},
  {name:"Amazon India",icon:"📦",desc:"Search listings; verify used/recycled condition",url:q=>`https://www.amazon.in/s?k=${encodeURIComponent(q)}`},
  {name:"Flipkart",icon:"🛍️",desc:"Books and stationery listings",url:q=>`https://www.flipkart.com/search?q=${encodeURIComponent(q)}`},
  {name:"IndiaMART",icon:"🏭",desc:"Wholesalers, manufacturers and bulk lots",url:q=>`https://www.indiamart.com/search.mp?ss=${encodeURIComponent(q)}`},
  {name:"OLX India",icon:"♻️",desc:"Local second-hand books and surplus stock",url:q=>`https://www.olx.in/items/q-${encodeURIComponent(q).replace(/%20/g,"-")}`},
  {name:"Quikr",icon:"📚",desc:"Classifieds and used-book listings",url:q=>`https://www.quikr.com/${encodeURIComponent(q)}+z`},
  {name:"Bookchor",icon:"📖",desc:"Pre-owned books and textbook searches",url:q=>`https://www.google.com/search?q=site%3Abookchor.com+${encodeURIComponent(q)}`},
  {name:"General web sellers",icon:"🌐",desc:"Find smaller dealers and local suppliers",url:q=>`https://www.google.com/search?q=${encodeURIComponent(q+" India buy price seller")}`}
];
function makeQuery(){
 const category=$("category").value, extra=$("extra").value.trim(), place=$("place").value.trim()||"India", qty=$("qty").value;
 let q=`${category} ${extra} ${qty==="Any quantity"?"":qty} ${place}`;
 if($("usedOnly").checked) q+=" scrap recycled waste paper used second hand old surplus";
 return q.replace(/\s+/g," ").trim();
}
function renderSites(){
 const q=makeQuery();
 $("sites").innerHTML=marketplaces.map(s=>`<article class="site"><div class="sitehead"><span class="siteicon">${s.icon}</span>${s.name}</div><small>${s.desc}</small><a href="${s.url(q)}" target="_blank" rel="noopener noreferrer">Open search ↗</a></article>`).join("");
}
["category","extra","place","qty","usedOnly"].forEach(id=>$(id).addEventListener("change",renderSites));
$("extra").addEventListener("input",renderSites);
$("searchBtn").addEventListener("click",()=>{renderSites();document.querySelector(".results").scrollIntoView({behavior:"smooth"});});
let deals=JSON.parse(localStorage.getItem("bdf-deals")||"[]");
function renderDeals(){
 const list=$("dealList");
 if(!deals.length){list.innerHTML='<p class="empty">No deals added yet.</p>';return;}
 list.innerHTML=deals.map((d,i)=>`<div class="deal"><div><strong>${escapeHtml(d.item)}</strong><small>₹${d.price.toFixed(2)} + ₹${d.delivery.toFixed(2)} delivery · ${d.units} pieces · ₹${(d.total/d.units).toFixed(2)} per piece</small></div><div class="total">₹${d.total.toFixed(2)}<br><button class="textbtn" data-remove="${i}">Remove</button></div></div>`).join("");
 list.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{deals.splice(Number(b.dataset.remove),1);saveDeals();}));
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function saveDeals(){localStorage.setItem("bdf-deals",JSON.stringify(deals));renderDeals();}
$("addBtn").addEventListener("click",()=>{
 const item=$("item").value.trim(),price=Number($("price").value),delivery=Number($("delivery").value||0),units=Math.max(1,Number($("units").value||1));
 if(!item||$("price").value===""||price<0||delivery<0){alert("Enter a product name and a valid item price.");return;}
 deals.push({item,price,delivery,units,total:price+delivery});saveDeals();
 $("item").value="";$("price").value="";$("delivery").value="";
});
$("clearBtn").addEventListener("click",()=>{if(confirm("Clear all compared deals?")){deals=[];saveDeals();}});
renderSites();renderDeals();
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;});
